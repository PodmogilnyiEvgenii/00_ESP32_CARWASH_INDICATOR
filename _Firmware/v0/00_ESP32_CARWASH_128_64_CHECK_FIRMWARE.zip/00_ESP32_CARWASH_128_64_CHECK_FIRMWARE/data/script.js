function save_button_click() {
	var s1;
	var s2;
	var s3;
	var s4;	
	
	s1 = document.getElementById("MB_SPEED").value;
	s2 = document.getElementById("MB_ADDRESS").value;	
	s3 = document.getElementById("WIFI_LOGIN").value;
	s4 = document.getElementById("WIFI_PASSWORD").value;
	
	var x = new XMLHttpRequest();
	x.open("GET", "/save?s1=" + s1 + '&s2=' + s2 + '&s3=' + s3 + '&s4=' + s4, true);
	x.onload = function (){
    alert( x.responseText);	
}
x.send(null);	

document.getElementById("save_button").innerText = "Сохранено";
}

function reset_save_button() {
document.getElementById("save_button").innerText = "Сохранить";
}


