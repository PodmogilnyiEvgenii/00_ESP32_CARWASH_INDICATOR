## FM6126 based LED Matrix Panel Reset ##

FM6216 panels require a special reset sequence before they can be used, check your panel chipset if you have issues. Refer to this example.
